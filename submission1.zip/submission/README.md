# Dicoding Bike Sharing Dashboard

## Setup environment
```
conda create --name main-ds
conda activate main-ds
pip install pandas plotly streamlit
```

## Run steamlit app
```
streamlit run dashboard.py
```