# Dicoding Bike Sharing Dashboard

## Setup environment
```
conda create --name main-ds
conda activate main-ds
pip install matplotlib pandas seaborn statsmodels streamlit
```

## Run steamlit app
```
streamlit run dashboard.py
```